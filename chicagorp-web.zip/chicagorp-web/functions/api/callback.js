import { createSessionCookie } from "../lib/session.js";

// GET /api/callback?code=...
// Discord redirige aquí después de que el usuario autoriza el login.
export async function onRequestGet({ request, env }) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");

  if (!code) {
    return Response.redirect(`${url.origin}/?acceso=denegado`, 302);
  }

  const redirectUri = `${url.origin}/api/callback`;

  // 1) Cambiamos el "code" por un token de acceso del usuario
  const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: env.DISCORD_CLIENT_ID,
      client_secret: env.DISCORD_CLIENT_SECRET,
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
    }),
  });

  if (!tokenRes.ok) {
    return Response.redirect(`${url.origin}/?acceso=denegado`, 302);
  }
  const tokenData = await tokenRes.json();

  // 2) Con ese token, preguntamos quién es el usuario
  const userRes = await fetch("https://discord.com/api/users/@me", {
    headers: { Authorization: `Bearer ${tokenData.access_token}` },
  });
  if (!userRes.ok) {
    return Response.redirect(`${url.origin}/?acceso=denegado`, 302);
  }
  const user = await userRes.json();

  // 3) Con el token del BOT (no del usuario), consultamos sus roles en el servidor
  const memberRes = await fetch(
    `https://discord.com/api/guilds/${env.DISCORD_GUILD_ID}/members/${user.id}`,
    { headers: { Authorization: `Bot ${env.DISCORD_BOT_TOKEN}` } }
  );

  if (!memberRes.ok) {
    // El usuario existe en Discord pero no está en el servidor Chicago Rp
    return Response.redirect(`${url.origin}/?acceso=denegado`, 302);
  }
  const member = await memberRes.json();

  // 4) Creamos la cookie de sesión firmada con su id, nombre y roles
  const session = {
    id: user.id,
    username: user.username,
    roles: member.roles || [],
    exp: Date.now() + 1000 * 60 * 60 * 12, // expira en 12 horas
  };
  const cookieValue = await createSessionCookie(session, env.SESSION_SECRET);

  const headers = new Headers();
  headers.append("Location", `${url.origin}/`);
  headers.append(
    "Set-Cookie",
    `chicagorp_session=${encodeURIComponent(
      cookieValue
    )}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=43200`
  );

  return new Response(null, { status: 302, headers });
}
